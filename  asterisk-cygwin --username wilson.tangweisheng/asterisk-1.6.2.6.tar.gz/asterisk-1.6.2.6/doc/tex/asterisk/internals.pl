# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/voicemail/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/odbcstorage/;
$ref_files{$key} = "$dir".q|node233.html|; 
$noresave{$key} = "$nosave";

$key = q/trunks/;
$ref_files{$key} = "$dir".q|node145.html|; 
$noresave{$key} = "$nosave";

1;

